#ifndef SHA3_H
#define SHA3_H

extern "C" int crypto_hash( unsigned char *out, const unsigned char *in, unsigned long long inlen );

#endif /* SHA3 */
