#pragma once

#define false   0
#define true    1

#define bool int
